/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.ineco.grails.alfresco;

/**
 *
 * @author Nacho
 */
public class AlfrescoIntegrationException extends Exception{

    public AlfrescoIntegrationException(String message) {
        super(message);
    }

    public AlfrescoIntegrationException(Throwable cause) {
        super(cause);
    }

    
    
}
